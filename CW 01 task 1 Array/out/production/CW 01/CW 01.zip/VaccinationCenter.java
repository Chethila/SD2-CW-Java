import java.util.Scanner;

public class VaccinationCenter {
    static String patientName;
    static int patientNum;
    static int boothNum = 0;
    static Scanner input = new Scanner(System.in);
    static String[] VaccinationCenter = new String[6];

    public static void main(String[] args) {

        //declaring variables.
//        Scanner input = new Scanner(System.in);
//        String patientName;
//        int patientNum;
//        int boothNum = 0;

        //declaring the main array.
//        String[] VaccinationCenter = new String[6];
        //calling the initialise array function.
        initialise(VaccinationCenter);

        //menu bar with a if-else block.
        String userInput;

        while (true) {
            System.out.println("Enter 100 or VVB: View all Vaccination Booths");
            System.out.println("Enter 101 or VEB: View all Empty Booths");
            System.out.println("Enter 102 or APB: Add Patient to a Booth");
            System.out.println("Enter 103 or RPB: Remove Patient from a Booth");
            System.out.println("Enter 104 or VPS: View Patients Sorted in alphabetical order");
            System.out.println("Enter 105 or SPD: Store Program Data into file");
            System.out.println("Enter 106 or LPD: Load Program Data from file");
            System.out.println("Enter 107 or VRV: View Remaining Vaccinations");
            System.out.println("Enter 108 or AVS: Add Vaccinations to the Stock");
            System.out.println("Enter 999 or EXT: Exit the Program");

            userInput = input.nextLine();
            if (userInput.equals("100")) {    //if statement to show all vaccination booths.
                for (int i = 0; i < 6; i++) {
                    System.out.println("Vaccination Booth"+" "+i+" "+VaccinationCenter[i]);
                }
            }
            else if (userInput.equals("101")) {  //if statement to show the empty booths.
                for (int x = 0; x < 6; x++) {
                    if (VaccinationCenter[x].equals("empty")) {
                        System.out.println("The booth"+" "+ x +"is"+" " + VaccinationCenter[x]);
                    }
                }
            }
            else if (userInput.equals("102")) {  //if statement to add a patient to the booth.
                addMember();
            }

            else if (userInput.equals("999")) {  //if statement to exit the programme.
                System.out.println("terminated");
                break;
            }
        }






//        while (boothNum < 6) {
//            for (int x = 0; x < 6; x++) {
//                if (VaccinationCenter[x].equals("empty")) {
//                    System.out.println("booth"+" "+ x +" "+"is empty.");
//                }
//                System.out.println("Enter a booth number(0-5) or 6 to exit :");
//                boothNum = input.nextInt();
//
//                System.out.println("Enter patient name for booth"+" "+ boothNum + " : ");
//                patientName = input.next();
//                VaccinationCenter[boothNum] = patientName;
//
//                for (int z = 0; z < 6; z++ ) {
//                    System.out.println("booth"+" "+ z +" "+"is occupied by"+" "+ VaccinationCenter[z]);
//                }
//            }
//        }
    }



    private static void initialise(String[] boothRef){
        for (int i = 0; i < 6; i++) {
            boothRef[i] = "empty" ;
        }
        System.out.println("initialise");
    }

    private static void addMember() {
        System.out.print("Enter the name of the patient :");
        patientName = input.next();
        System.out.print("Enter the booth number :");
        boothNum = input.nextInt();
        VaccinationCenter[boothNum] = patientName;
    }
}
