import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Formula1ChampionshipManager implements ChampionshipManager {
    private static String driverName;
    private static String driverLocation;
    private static String driverTeam;
    private static int firstPositions;
    private static int secondPositions;
    private static int thirdPositions;
    private static int points;
    private static int noParticipation;

    public static void main(String[] args) throws ParseException {

        LinkedList<Formula1Driver> driverList = new LinkedList<>();
        Scanner input1 = new Scanner(System.in);
        int userInput;

        while (true) {
            System.out.println("Enter 1 to add a Driver: ");
            System.out.println("Enter 2 to delete a Driver: ");
            System.out.println("Enter 3 to change the constructor team of a Driver: ");
            System.out.println("Enter 4 to display statistics of an existing Driver: ");
            System.out.println("Enter 5 to display the Formula 1 Driver Table: ");
            System.out.println("Enter 6 to add a new race completed information: ");
            System.out.println("Enter 7 to save all the information in a file: ");
            System.out.println("Enter 8 to display or edit the past Formula 1 Driver Table: ");

            userInput = input1.nextInt();

            if (userInput == 1) {        //Adding a driver to the system.

                Scanner input2 = new Scanner(System.in);
                System.out.print("Enter the name of the driver: ");
                driverName = input2.next();

                Scanner input3 = new Scanner(System.in);
                System.out.print("Enter the location of the driver : ");
                driverLocation = input3.next();

                Scanner input4 = new Scanner(System.in);
                System.out.print("Enter the constructor team of the driver : ");
                driverTeam = input4.next();

                Scanner input5 = new Scanner(System.in);
                System.out.print("Enter the number of 1st positions gained : ");
                firstPositions = input5.nextInt();

                Scanner input6 = new Scanner(System.in);
                System.out.print("Enter the number of 2nd positions gained : ");
                secondPositions = input6.nextInt();

                Scanner input7 = new Scanner(System.in);
                System.out.print("Enter the number of 3rd positions gained : ");
                thirdPositions = input7.nextInt();

                Scanner input8 = new Scanner(System.in);
                System.out.print("Enter the number of races participated : ");
                noParticipation = input8.nextInt();

                Scanner input9 = new Scanner(System.in);
                System.out.print("Enter the number of points gained : ");
                points = input9.nextInt();
                System.out.println("-------------------------");

                driverList.add(new Formula1Driver(driverName, driverLocation, driverTeam, firstPositions, secondPositions, thirdPositions, points, noParticipation));
            }

            else if (userInput == 2) {         //Deleting a driver from the system.
                Scanner input10 = new Scanner(System.in);
                System.out.println("Enter the name of the driver you want to delete: ");
                String deleteDriver = input10.next();
                boolean check = true;

                for (int x = 0; x < driverList.size(); x++) {
                    if (driverList.get(x).getDriverName().equalsIgnoreCase(deleteDriver)) {
                        System.out.println(deleteDriver + " has been deleted from the championship.");
                        driverList.remove(x);
                        check = false;
                        System.out.println("-------------------------");
                        break;
                    }
                }
                if (check) {
                    System.out.println("Couldn't find a driver called " + deleteDriver + ". Please enter the name again!");
                    System.out.println("-------------------------");
                }
//                System.out.println("Couldn't find a driver called "+deleteDriver+". Please enter the name again!");
            }

            else if (userInput == 3) {        //Changing the driver constructor team.
                Scanner input11 = new Scanner(System.in);
                System.out.println("Enter the name of the driver you want to change the constructor team: ");
                String name = input11.next();
                boolean check2 = true;
                boolean check3 = true;

                for (int y = 0; y < driverList.size(); y++) {
                    if (driverList.get(y).getDriverName().equalsIgnoreCase(name)) {
                        Scanner input12 = new Scanner(System.in);
                        System.out.println("Enter the new constructor team of the driver: ");
                        String newTeam = input12.next();
                        check2 = false;

                        for (Formula1Driver formula1Driver : driverList) {
                            if (formula1Driver.getDriverTeam().equalsIgnoreCase(newTeam)) {
                                driverList.get(y).setDriverTeam(newTeam);
                                System.out.println(name + " has been added to the " + newTeam + " new constructor team.");
                                check3 = false;
                                System.out.println("-------------------------");
                                break;
                            }
                        }
                        if (check3) {
                            System.out.println("There is no existing constructor team called " + newTeam + ". Please try with another constructor team.");
                            System.out.println("-------------------------");
                        }
                    }
                }
                if (check2) {
                    System.out.println("Couldn't find a driver called " + name + ". Please re-enter the name of the driver. ");
                    System.out.println("-------------------------");
                }
            }

            else if (userInput == 4) {            //Displaying the statistics of an existing driver.
                Scanner input13 = new Scanner(System.in);
                System.out.println("Enter the name of the driver you want to check statistics: ");
                String checkName = input13.next();
                boolean check4 = true;
                for (int i = 0; i < driverList.size(); i++) {
                    if (driverList.get(i).getDriverName().equalsIgnoreCase(checkName)) {
                        check4 = false;
                        System.out.println("Name :- " + driverList.get(i).getDriverName() +
                                "\n Location :- " + driverList.get(i).getDriverLocation() +
                                "\n Constructor team :- " + driverList.get(i).getDriverTeam() +
                                "\n Number of 1st Positions :- " + driverList.get(i).getFirstPositions() +
                                "\n Number of 2nd Positions :- " + driverList.get(i).getSecondPositions() +
                                "\n Number of 3rd Positions :- " + driverList.get(i).getThirdPositions() +
                                "\n Number of Races Participated :- " + driverList.get(i).getNoParticipation() +
                                "\n Number of Points Gained :- " + driverList.get(i).getPoints());
                        System.out.println("-------------------------");
                    }
                }
                if (check4) {
                    System.out.println("Couldn't find a driver called " + checkName + ". Please re-enter the name of the driver. ");
                    System.out.println("-------------------------");
                }
            }

            else if (userInput == 5) {               //F1 driver table.Points Descending order.

//                Collections.sort(driverList, Comparator.comparingInt(Formula1Driver::getPoints).reversed());
                Collections.reverse(driverList);             //TODO sort it to the descending order.

                for (int x = 0; x < driverList.size(); x++) {
                    System.out.println("Name :- " + driverList.get(x).getDriverName() +
                            "\n Location :- " + driverList.get(x).getDriverLocation() +
                            "\n Constructor team :- " + driverList.get(x).getDriverTeam() +
                            "\n Number of 1st Positions :- " + driverList.get(x).getFirstPositions() +
                            "\n Number of 2nd Positions :- " + driverList.get(x).getSecondPositions() +
                            "\n Number of 3rd Positions :- " + driverList.get(x).getThirdPositions() +
                            "\n Number of Races Participated :- " + driverList.get(x).getNoParticipation() +
                            "\n Number of Points Gained :- " + driverList.get(x).getPoints());
                    System.out.println("....................");
                }
            }

            else if (userInput == 6) {                          //to add a completed race statistics.       //TODO need to add the date of the race.
                Scanner input17 = new Scanner(System.in);
                System.out.println("Enter the race date: ");
                String raceDate = input17.next();
                Date date;
                date = new SimpleDateFormat("dd-MM-yyyy").parse(raceDate);

                for (int y = 0; y < driverList.size(); y++) {
                    Scanner input15 = new Scanner(System.in);
                    System.out.println("Did this driver participate the race? " + driverList.get(y).getDriverName() + " type yes/no ?");
                    String answer = input15.next();
                    if (answer.equalsIgnoreCase("yes")) {
                        Scanner input16 = new Scanner(System.in);
                        System.out.println("Please enter the Position of the driver: ");
                        int position = input16.nextInt();
                        int racePoints;

                        switch (position) {                            //switch case for the points system.
                            case 1:
                                racePoints = 25;
                                break;
                            case 2:
                                racePoints = 18;
                                break;
                            case 3:
                                racePoints = 15;
                                break;
                            case 4:
                                racePoints = 12;
                                break;
                            case 5:
                                racePoints = 10;
                                break;
                            case 6:
                                racePoints = 8;
                                break;
                            case 7:
                                racePoints = 6;
                                break;
                            case 8:
                                racePoints = 4;
                                break;
                            case 9:
                                racePoints = 2;
                                break;
                            case 10:
                                racePoints = 1;
                                break;
                            default:
                                racePoints = 0;
                                break;
                        }
                        int pointFinal = driverList.get(y).getPoints() + racePoints;                   //updating the points and the number of participated races.
                        int partiF = driverList.get(y).getNoParticipation() + 1;
                        driverList.get(y).setPoints(pointFinal);
                        driverList.get(y).setNoParticipation(partiF);

                        if (position == 1) {                                                          //updating the main 3 positions.
                            int fisrtF = driverList.get(y).getFirstPositions() + 1;
                            driverList.get(y).setFirstPositions(fisrtF);
                        } else if (position == 2) {
                            int secondF = driverList.get(y).getSecondPositions() + 1;
                            driverList.get(y).setSecondPositions(secondF);
                        } else if (position == 3) {
                            int thirdF = driverList.get(y).getSecondPositions() + 1;
                            driverList.get(y).setSecondPositions(thirdF);
                        }
                    }
                }
            }
            else if (userInput == 7) {

            }

            else{
                    break;
                }
            }
        }
    }
